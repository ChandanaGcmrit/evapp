from django.apps import AppConfig


class SmartEvAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Smart_EV_App'
